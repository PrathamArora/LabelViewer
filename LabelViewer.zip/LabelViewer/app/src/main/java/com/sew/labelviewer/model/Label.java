package com.sew.labelviewer.model;

import org.json.JSONObject;

import java.io.Serializable;

public class Label implements Serializable {
    private String ControlGuId, ControlId, ControlPlaceHolder,
            ControlText, ControlTitle, ErrorMessage,
            LanguageCode, LastUpdated, ModuleGuId;

    private Label(String controlGuId, String controlId, String controlPlaceHolder,
                  String controlText, String controlTitle, String errorMessage,
                  String languageCode, String lastUpdated, String moduleGuId) {

        ControlGuId = controlGuId;
        ControlId = controlId;
        ControlPlaceHolder = controlPlaceHolder;
        ControlText = controlText;
        ControlTitle = controlTitle;
        ErrorMessage = errorMessage;
        LanguageCode = languageCode;
        LastUpdated = lastUpdated;
        ModuleGuId = moduleGuId;
    }

    public static Label getLabelFromJSON(JSONObject labelJSON) {
        try {
            return new Label(labelJSON.getString("ControlGuId"), labelJSON.getString("ControlId"), labelJSON.getString("ControlPlaceHolder")
                    , labelJSON.getString("ControlText"), labelJSON.getString("ControlTitle"), labelJSON.getString("ErrorMessage")
                    , labelJSON.getString("LanguageCode"), labelJSON.getString("LastUpdated"), labelJSON.getString("ModuleGuId"));
        } catch (Exception e) {
            return null;
        }

    }

    public String getControlGuId() {
        return ControlGuId;
    }

    public String getControlId() {
        return ControlId;
    }

    public String getControlPlaceHolder() {
        return ControlPlaceHolder;
    }

    public String getControlText() {
        return ControlText;
    }

    public String getControlTitle() {
        return ControlTitle;
    }

    public String getErrorMessage() {
        return ErrorMessage;
    }

    public String getLanguageCode() {
        return LanguageCode;
    }

    public String getLastUpdated() {
        return LastUpdated;
    }

    public String getModuleGuId() {
        return ModuleGuId;
    }
}
