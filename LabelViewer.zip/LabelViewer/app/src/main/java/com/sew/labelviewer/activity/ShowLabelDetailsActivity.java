package com.sew.labelviewer.activity;


import android.os.Bundle;
import android.widget.TextView;

import com.sew.labelviewer.R;
import com.sew.labelviewer.model.Label;

import java.util.Objects;

public class ShowLabelDetailsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_label_details);

        Label selectedLabel = (Label) getIntent().getSerializableExtra(BaseActivity.CURRENT_LABEL);

        ((TextView) findViewById(R.id.tvControlGuId)).setText(Objects.requireNonNull(selectedLabel).getControlGuId());

        ((TextView) findViewById(R.id.tvControlId)).setText(Objects.requireNonNull(selectedLabel).getControlId());

        ((TextView) findViewById(R.id.tvControlPlaceHolder)).setText(Objects.requireNonNull(selectedLabel).getControlPlaceHolder());

        ((TextView) findViewById(R.id.tvControlText)).setText(Objects.requireNonNull(selectedLabel).getControlText());

        ((TextView) findViewById(R.id.tvControlTitle)).setText(Objects.requireNonNull(selectedLabel).getControlTitle());

        ((TextView) findViewById(R.id.tvErrorMessage)).setText(Objects.requireNonNull(selectedLabel).getErrorMessage());

        ((TextView) findViewById(R.id.tvLanguageCode)).setText(Objects.requireNonNull(selectedLabel).getLanguageCode());

        ((TextView) findViewById(R.id.tvLastUpdated)).setText(Objects.requireNonNull(selectedLabel).getLastUpdated());

        ((TextView) findViewById(R.id.tvModuleGuId)).setText(Objects.requireNonNull(selectedLabel).getModuleGuId());

    }
}
