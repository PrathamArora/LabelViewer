package com.sew.labelviewer.activity;

import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {
    public static final String LABEL_ASSET_DIR = "labeltable.json";
    public static final String CURRENT_LABEL = "currentLabel";

    public void showToast(String message){
        Toast.makeText(BaseActivity.this, message, Toast.LENGTH_SHORT).show();
    }

}
