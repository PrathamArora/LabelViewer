package com.sew.labelviewer.activity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.sew.labelviewer.R;
import com.sew.labelviewer.adapter.LabelAdapter;
import com.sew.labelviewer.utility.BasicUtilities;

public class ShowLabelActivity extends BaseActivity {

    RecyclerView rvLanguageLabels;
    LabelAdapter labelAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_label);

        rvLanguageLabels = findViewById(R.id.rvLanguageLabels);
        labelAdapter = new LabelAdapter(this, BasicUtilities.getLabelList());
        LinearLayoutManager recyclerLayoutManager = new LinearLayoutManager(this);
        recyclerLayoutManager.setOrientation(RecyclerView.VERTICAL);

        rvLanguageLabels.setLayoutManager(recyclerLayoutManager);
        rvLanguageLabels.setAdapter(labelAdapter);
    }
}
